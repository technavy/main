# Copyright (c) 2021, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt

from frappe.tests import IntegrationTestCase

# import frappe


class TestInterviewRound(IntegrationTestCase):
	pass
