# Copyright (c) 2015, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt

from frappe.tests import IntegrationTestCase

# test_records = frappe.get_test_records('Interest')


class TestInterest(IntegrationTestCase):
	pass
