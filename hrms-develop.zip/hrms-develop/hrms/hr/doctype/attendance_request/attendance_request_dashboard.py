def get_data():
	return {"fieldname": "attendance_request", "transactions": [{"items": ["Attendance"]}]}
