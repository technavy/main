# Copyright (c) 2015, Frappe Technologies Pvt. Ltd. and Contributors and Contributors
# See license.txt

from frappe.tests import IntegrationTestCase

# test_records = frappe.get_test_records('Expense Claim Type')


class TestExpenseClaimType(IntegrationTestCase):
	pass
